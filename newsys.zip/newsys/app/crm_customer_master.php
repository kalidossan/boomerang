<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class crm_customer_master extends Model
{
    //
}
