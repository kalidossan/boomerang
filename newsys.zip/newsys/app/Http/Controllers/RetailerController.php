<?php

namespace App\Http\Controllers;

use DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Event;
use App\Category;
use MaddHatter\LaravelFullcalendar\Facades\Calendar;
use Carbon\Carbon;

class RetailerController extends Controller {

    public function index() {
        if (Auth::user()->biz_id == 0) {
            return redirect('admin');
        }


        $events = [];
        $data = Event::all();
        if ($data->count()) {
            foreach ($data as $key => $value) {
                $events[] = Calendar::event(
                                $value->title, true, new \DateTime($value->start_date), new \DateTime($value->end_date . ' +1 day'), null, [
                            'color' => '#a94442',
                            'url' => 'home#message',
                                ]
                );
            }
        }
        $categories_label = DB::table('crm_categories_master')
                ->select('CCM_ID', 'CCM_LABEL_NAME')
                ->where('ccm_ret_biz_id', Auth::user()->biz_id)
                ->get();
        $categories = DB::table('crm_cat_values_master')
                ->select('CCVM_ID', 'CCVM_VALUE', 'CCVM_CCM_ID')
                ->get();
        $customer = DB::table('CRM_CUSTOMER_MASTER')->get();

        if (isset($request->cid)) {
            $cid = $request->cid;
        } else {
            $cid = 8;
        }

        $retailer_categories = DB::table('crm_categories_master')->select('*')->where('ccm_ret_biz_id', Auth::user()->biz_id)->get();
        $retailer_categories_values = (new Category)->categoryValues($cid);

        $calendar = Calendar::addEvents($events);
        return view('retailer.retailer', compact('calendar', 'pass', 'visit_count', 'categories', 'categories_label', 'customer', 'message_history', 'retailer_categories', 'retailer_categories_values'));
    }

    public function password_reset(Request $request) {
//        if (Hash::check('plain-text', $hashedPassword)) {
//        }
                
            $udata['password'] = \Hash::make($request->password);
            DB::table('users')->where('role_id','<>',1)->where('biz_id',Auth::user()->biz_id)->update($udata);
        
    }

}
