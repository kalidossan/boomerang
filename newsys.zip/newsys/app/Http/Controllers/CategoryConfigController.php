<?php
namespace App\Http\Controllers;
use DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Category;

class CategoryConfigController extends Controller {
    
    public function index(Request $request){
        
       if(isset($request->cid)) {
           $cid = $request->cid;
       }
       else{
           $cid = 8;
       }       
        
       $data['categories'] = DB::table('crm_categories_master')->select('*')->where('ccm_ret_biz_id',Auth::user()->biz_id)->get();      
       $data['values'] = (new Category)->categoryValues($cid);       
       // $data['values'] = DB::table('crm_cat_values_master')->get();
        //return view('category_config',$data);  
        return view('retailer.retailer_config',$data);     
    }
    
    public function cat_value(Request $request){
         if(isset($request->cid)) {
           $cid = $request->cid;
       }
       else{
           $cid = 8;
       }  
        
               $data['values'] = (new Category)->categoryValues($cid);    
               
               return response()->json($data);

    }

    public function store(Request $request) {

        \DB::beginTransaction();
        try {
            
            $data['ccm_ret_biz_id'] = Auth::user()->biz_id;
            $data['ccm_label_name'] = $request->category_label;           
            $data['ccm_created_dt'] = Carbon::now();
            $data['ccm_created_by'] = Auth::user()->biz_id;
            $data['ccm_modified_dt'] = Carbon::now();
            $data['ccm_modified_by'] = Auth::user()->biz_id;

            $id = DB::table('crm_categories_master')->insertGetId($data);
          
             $categories = explode(',', $request->category_value);
             
             foreach($categories as $category){                         
                $cvdata['ccvm_ccm_id'] = $id;
                $cvdata['ccvm_value'] = $category;
                $cvdata['ccvm_created_dt'] = Carbon::now();
                $cvdata['ccvm_created_by'] = Auth::user()->biz_id;
                $cvdata['ccvm_modified_dt'] = Carbon::now();
                $cvdata['ccvm_modified_by'] = Auth::user()->biz_id;
                DB::table('crm_cat_values_master')->insert($cvdata);                
             }


            \DB::commit();

            $success = true;
        } catch (\Exception $e) {
            $success = false;

            echo $e;

            print "Customer Not Saved.";

            \DB::rollback();
        }



        return response()->json(['success' => 'Category Saved Successfully']);
    }

}
