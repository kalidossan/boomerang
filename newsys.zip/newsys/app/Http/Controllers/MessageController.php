<?php

namespace App\Http\Controllers;

use DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Message;

class MessageController extends Controller {

    public function message_center(Request $request) {

        $categories_label = DB::table('crm_categories_master')
                ->select('CCM_ID', 'CCM_LABEL_NAME')
                ->where('ccm_ret_biz_id', Auth::user()->biz_id)
                ->get();
        // dd($categories_label[0]->CCM_ID);
        $categories = DB::table('crm_cat_values_master')
                ->select('CCVM_ID', 'CCVM_VALUE', 'CCVM_CCM_ID')
                ->get();
        //$plan = DB::table('CRM_PLAN_ENTRY_MASTER')->get();

        return view('retailer.message_center', compact('categories', 'categories_label'));
    }



    public function message_history(Request $request) {

        $data['message_history'] = DB::table('CRM_MC_HISTORY')->where('CMH_RET_BIZ_ID',Auth::user()->biz_id)->get();


        return view('retailer.message_history', $data);
    }

    public function store(Request $request) {

        \DB::beginTransaction();
        try {



            if ($request->c_message_type == 0) {


                if($request->c_gender_group=='2'){

                    $select_gender=[0,1];

                }
                else{

                    $select_gender = array($request->c_gender_group);

                }

                if($request->c_cust_pros_target=='2'){

                    $select_audience= [0,1];

                }
                else{

                    $select_audience= array($request->c_cust_pros_target);

                }

                $customer = DB::table('CRM_CUSTOMER_MASTER')
                            ->join('CRM_CUST_RET_LINK','CRM_CUST_RET_LINK.CCRL_CCM_CUST_ID','=','CRM_CUSTOMER_MASTER.CCM_CUST_ID')
                            ->select('CCM_MOBILE_NO')
                            ->whereIn('CCM_GENDER',$select_gender)
                            ->orWhereIn('CCRL_CUST_PROS_TYPE',$select_audience)
                            ->get();

                $cust_no = array();

                foreach ($customer as $key => $value) {

                    $cust_no[] = $value->CCM_MOBILE_NO;
                    
                }

                $mobile_no = implode(',', $cust_no);



                $valid_till = date_create($request->c_valid_till);
                $valid_till_time = date_create($request->c_valid_till_time);
                $data['cme_ret_biz_id'] = Auth::user()->biz_id;
                $data['cme_msg_type'] = $request->c_message_type;
                $data['cme_msg_txt'] = $request->c_msg_txt;
                $data['cme_title'] = $request->c_message_title;
                $data['cme_msg_2b_sent'] = count($customer);
                $data['cme_ccm_gender'] = $request->c_gender_group;
                $data['cme_ccrl_cust_pros_type'] = $request->c_cust_pros_target;
                $data['cme_msg_status'] = 0;
                $data['cme_before_days'] = 0;
                $data['cme_schd_date'] = date_format($valid_till, "Y-m-d H:i:s");
                $data['cme_schd_time'] = date_format($valid_till_time, "H:i:s");
                $data['cme_created_dt'] = Carbon::now();
                $data['cme_created_by'] = Auth::user()->biz_id;
                $data['cme_modified_dt'] = Carbon::now();
                $data['cme_modified_by'] = Auth::user()->biz_id;
                
                $no_customer = count($customer);

	        $sms_count = strlen($request->c_msg_txt);

                $data['CME_SMS_COUNT']= $sms_count*$no_customer;
                

                $bmid = DB::table('crm_mc_events')->insertGetId($data);


                $cid = explode(',', $request->c_mc_category_values_id);

                foreach ($cid as $key => $value) {

                    $category_label = DB::table('crm_cat_values_master')->where('CCVM_ID', $value)->first()->CCVM_CCM_ID;
                    $cdata['cmcv_cme_cmb_id'] = $bmid;
                    $cdata['cmcv_ccm_label_name'] = $category_label;
                    $cdata['cmcv_ccvm_value'] = $value;
                    $cdata['cmcv_created_dt'] = Carbon::now();
                    $cdata['cmcv_created_by'] = Auth::user()->biz_id;
                    $cdata['cmcv_modified_dt'] = Carbon::now();
                    $cdata['cmcv_modified_by'] = Auth::user()->biz_id;
                    DB::table('crm_mc_cat_values')->insert($cdata);
                }
            } else {
                $valid_till = date_create($request->c_valid_till);
                $valid_till_time = date_create($request->c_valid_till_time);
                $data['cmb_ret_biz_id'] = Auth::user()->biz_id;
                $data['cmb_msg_type'] = $request->c_message_type;
                $data['cmb_msg_txt'] = $request->c_msg_txt;
                $data['cmb_title'] = $request->c_message_title;
                $data['cmb_msg_2b_sent'] = "";
                $data['cmb_ccm_gender'] = $request->c_gender_group;
                $data['cmb_ccrl_cust_pros_type'] = $request->c_cust_pros_target;
                $data['cmb_msg_status'] = 0;
                $data['cmb_before_days'] = 0;
                $data['cmb_valid_date'] = date_format($valid_till, "Y-m-d H:i:s");
                $data['cmb_schd_time'] = date_format($valid_till_time, "H:i:s");
                $data['cmb_created_dt'] = Carbon::now();
                $data['cmb_created_by'] = Auth::user()->biz_id;
                $data['cmb_modified_dt'] = Carbon::now();
                $data['cmb_modified_by'] = Auth::user()->biz_id;
                $id = DB::table('crm_mc_bdays')->insertGetId($data);

                $cid = explode(',', $request->c_mc_category_values_id);

                foreach ($cid as $key => $value) {

                    $category_label = DB::table('crm_cat_values_master')->where('CCVM_ID', $value)->first()->CCVM_CCM_ID;
                    $cdata['cmcv_cme_cmb_id'] = $id;
                    $cdata['cmcv_ccm_label_name'] = $category_label;
                    $cdata['cmcv_ccvm_value'] = $value;
                    $cdata['cmcv_created_dt'] = Carbon::now();
                    $cdata['cmcv_created_by'] = Auth::user()->biz_id;
                    $cdata['cmcv_modified_dt'] = Carbon::now();
                    $cdata['cmcv_modified_by'] = Auth::user()->biz_id;
                    DB::table('crm_mc_cat_values')->insert($cdata);
                }
            }



            \DB::commit();

            $success = true;
        } catch (\Exception $e) {
            $success = false;

            echo $e;

            print "Customer Not Saved.";

            \DB::rollback();
        }

        return response()->json(['success' => 'Customer Saved Successfully']);
    }

//    public function msgModerator(Request $request) {
//
//        $data['moderator'] = (new Message)->msgModerator();
//        return view('msg_moderator', $data);
//    }
//    
     public function msgModerator(Request $request) {
        $valid_till_date = date_create($request->till_date);
        $valid_till_time = date_create($request->till_time);
        $data['cme_schd_date'] = date_format($valid_till_date, "Y-m-d H:i:s");
        $data['cme_schd_time'] = date_format($valid_till_time, "H:i:s");
        $data['cme_msg_txt'] = $request->msg_content;
        $data['cme_msg_status'] = 1;
        $bmid = DB::table('crm_mc_events')->where('CME_ID',$request->msg_id)->update($data);
        return response()->json(['success' => 'Messages Approved']);
    }

}
