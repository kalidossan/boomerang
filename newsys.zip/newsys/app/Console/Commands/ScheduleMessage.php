<?php
namespace App\Console\Commands;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Softon\Sms\Facades\Sms;  

class ScheduleMessage extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'Approved:Message';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Approved Messages';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */

  

    public function handle()
    {


      echo "hello";
     $phone_numbers = DB::table('CRM_CUSTOMER_MASTER')
                       ->leftJoin('CRM_MC_EVENTS', 'CRM_MC_EVENTS.CME_CCM_GENDER', '=', 'CRM_CUSTOMER_MASTER.CCM_GENDER')
                       ->leftJoin('CRM_MC_EVENTS','CRM_CUSTOMER_MASTER.CCM_CUST_PROS_TYPE','=','CRM_MC_EVENTS.CME_CCRL_CUST_PROS_TYPE')
                       ->select('CCM_MOBILE_NO')
                       ->get();
     
     
               print_r($phone_numbers);
     
     
     
     //$scheduled_sms = Sms::send(['9944514048'],'sms.test',['user'=>'Kali','token'=>'tkn boom1',])->response();  
     
     
     
     //DB::table('categories')->insert($data);
     //return redirect('sms/status');
    }

}
