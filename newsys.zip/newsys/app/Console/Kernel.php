<?php
namespace App\Console;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Softon\Sms\Facades\Sms;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel {

    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [
        Commands\ScheduleMessage::class,
        Commands\ApproveMessage::class,
    ];

    /**
     * Define the application's command schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule  $schedule
     * @return void
     */
    protected function messageHistory($id) {

        $message_sheduling = DB::table('CRM_MC_EVENTS')
                ->where('CME_ID', $id)
                ->first();

        $mhdata['CMH_RET_BIZ_ID'] = $message_sheduling->CME_RET_BIZ_ID;
        $mhdata['CMH_CMCVH_ID'] = 0;
        $mhdata['CMH_MSG_TYPE'] = $message_sheduling->CME_MSG_TYPE;

        $mhdata['CMH_TITLE'] = $message_sheduling->CME_TITLE;
        $mhdata['CMH_CONTENT'] = $message_sheduling->CME_MSG_TXT;
        $mhdata['CMH_CCM_GENDER'] = $message_sheduling->CME_CCM_GENDER;
        $mhdata['CMH_CCRL_CUST_PROS_TYPE'] = $message_sheduling->CME_CCRL_CUST_PROS_TYPE;
        $mhdata['CMH_CREATED_DT'] = Carbon::now();

        DB::table('CRM_MC_HISTORY')->insert($mhdata);
        $data['message_sheduling'] = DB::table('CRM_MC_EVENTS')->where('CME_ID', '=', $id)->update(['CME_MSG_STATUS'=>2]);
        
    }

    protected function messageHistoryFailure($id, $reason) {

        $mhdata['CMH_ID'] = $id;
        $mhdata['Link_ID'] = 0;
        $mhdata['CMHF_Failure_Reason'] = $reason;
        $mhdata['CMHF_CREATED_DT'] = Carbon::now();
        DB::table('CRM_MC_HISTORY_FAILURE')->insert($mhdata);
    }

    protected function messageHistorySuccess($id) {
        $mhdata['CMH_ID'] = $id;
        $mhdata['Link_ID'] = 0;
        $mhdata['CMHS_CREATED_DT'] = Carbon::now();
        DB::table('CRM_MC_HISTORY_SUCCESS')->insert($mhdata);
    }

    protected function createMessageHistory($error_response_code,$error_response_value,$id)
    {
         $this->messageHistory($id);

         if ($error_response_code== 1) 
         {                              
          $this->messageHistoryFailure($id, $error_response_value);
         } 
         else {                               
            $this->messageHistorySuccess($msg->CME_ID);
         }

         $message_sheduling = DB::table('CRM_MC_EVENTS')
                ->where('CME_ID', $id)
                ->first();

         smsUpdate($message_sheduling->CME_RET_BIZ_ID,0,$message_sheduling->CME_SMS_COUNT);
    }



    protected function sendWishes($phone_numbers){



          $message = DB::table('CRM_MC_EVENTS')->where('CME_MSG_STATUS', 1)->get();

                    if (count($message) != 0) {
                        foreach ($message as $msg) {
                            $msg_txt = $msg->CME_MSG_TXT;
                            $msg_title = $msg->CME_TITLE;

                    foreach ($phone_numbers as $phone) {

                    $wishes = Sms::send([$phone], 'sms.anniversay', ['title' => $msg_title, 'msg' => $msg_txt,])->response();
                    $this->createMessageHistory($wishes['status']['error'],$events['response'],$msg->CME_ID);
            
        }

                            

                           
                        }
                    }


     

    }


    
    protected function sendMessages($phone_numbers){



          $message = DB::table('CRM_MC_EVENTS')->where('CME_MSG_STATUS', 1)->get();

                    if (count($message) != 0) {
                        foreach ($message as $msg) {
                            $msg_txt = $msg->CME_MSG_TXT;
                            $msg_title = $msg->CME_TITLE;

                    foreach ($phone_numbers as $phone) {

                    $events = Sms::send([$phone], 'sms.anniversay', ['title' => $msg_title, 'msg' => $msg_txt,])->response();
                    $this->createMessageHistory($events['status']['error'],$events['response'],$msg->CME_ID);
            
        }

                            

                           
                        }
                    }


     

    }


    // protected function sendMessages($phone_numbers){

    //       $message = DB::table('CRM_MC_EVENTS')->where('CME_MSG_STATUS', 1)->get();

    //                 if (count($message) != 0) {
    //                     foreach ($message as $msg) {
    //                         $msg_txt = $msg->CME_MSG_TXT;
    //                         $msg_title = $msg->CME_TITLE;

    //                         $events = Sms::send([$phone_numbers], 'sms.anniversay', ['title' => $msg_title, 'msg' => $msg_txt,])->response();

    //                         $this->createMessageHistory($events['status']['error'],$events['response'],$msg->CME_ID);

                           
    //                     }
    //                 }
    // }


    protected function wishes(Schedule $schedule){
              $schedule->call(function() {

                   $phone_numbers = DB::table('CRM_CUSTOMER_MASTER')
                           ->select('CCM_MOBILE_NO')
                           ->whereDay('CCM_DOB', date("d"))
                           ->whereMonth('CCM_DOB', date("m"))
                           ->get();
                   $pn = array();

                   foreach ($phone_numbers as $phone) {
                    //linkInfoFromMobileNo($phone);
                       $pn[] = $phone->CCM_MOBILE_NO;
                   }

                   $this->sendWishes($pn);
                  
               })->name('Birthday Wishes')
               ->withoutOverlapping()
               ->cron('* * * * * *');
    }

    protected function schedule(Schedule $schedule) {
        $schedule->call(function(){
                    $phone_numbers = DB::table('CRM_CUSTOMER_MASTER')
                            ->leftJoin('crm_mc_events as a', 'a.CME_CCM_GENDER', '=', 'CRM_CUSTOMER_MASTER.CCM_GENDER')
                            ->leftJoin('crm_mc_events as b', 'CRM_CUSTOMER_MASTER.CCM_CUST_PROS_TYPE', '=', 'b.CME_CCRL_CUST_PROS_TYPE')
                            ->select('CCM_MOBILE_NO', 'CCM_FIRST_NAME')
                            ->whereNotNull('CCM_MOBILE_NO')
                            ->get();

                    $pn = array();
                    foreach ($phone_numbers as $phone) {
                        $pn[] = $phone->CCM_MOBILE_NO;

                    }

                    $events_no = array_unique($pn);

                    $ph_no = "'" . implode("','", $events_no) . "'";

                    $this->sendMessages($events_no);
                    
                  
                })->name('events')
                ->withoutOverlapping()
                ->cron('* * * * * *');

        

        $this->wishes($schedule);




          // $schedule->call(function (){
          //          $phone_numbers = DB::table('CRM_CUSTOMER_MASTER')
          //                  ->select('CCM_MOBILE_NO')
          //                  ->whereDay('CCM_DOA', date("d"))
          //                  ->whereMonth('CCM_DOA', date("m"))
          //                  ->get();
          //          $pn = array();
          //          foreach ($phone_numbers as $phone) {
          //              $pn[] = $phone->CCM_MOBILE_NO;
          //          }
          //          $anniversary = array_unique($pn);

          //          $anniversary_sms = "'" . implode("','", $anniversary) . "'";
          //          echo $anniversary_sms;

          //          $scheduled_anniversay = Sms::send([$anniversary_sms], 'sms.anniversay', ['user' => 'Kali', 'token' => 'tkn boom1',])->response();
          //          if ($scheduled_anniversay['status']['error'] == 1) {
          //              $this->messageHistory();
          //              $this->messageHistoryFailure($scheduled_anniversay['response']);
          //              $this->messageHistorySuccess();
          //          } else {
          //              $this->messageHistory();
          //              $this->messageHistorySuccess();
          //          }
          //      })->name('Anniversary Wishes')
          //      ->withoutOverlapping()
          //      ->cron('* * * * * *');

        $schedule->command('Schedule:Message')->name('schedule')->withoutOverlapping()->cron('* * * * * *');
        $schedule->command('Approved:Message')->name('approve')->withoutOverlapping()->cron('* * * * * *');
    }

    /**
     * Register the commands for the application.
     *
     * @return void
     */
    protected function commands() {
        $this->load(__DIR__ . '/Commands');

        require base_path('routes/console.php');
    }

}
