<div class="col-sm-12 panel">

        <section class="content">

            <form  id="plan_entry_form">

                <div class="box-body">
                    <div class="row">
                        <div class="col-md-6">
                            <input type="hidden" value="<?php echo e(csrf_token()); ?>" id="plan_token" name="plan_token" />
                            <div class="plan">
                                <select name="plan_entry_master" id="plan_entry_master" required="required" >
                                    <option value="0">Subscription</option>
                                    <option value="1">Renewal</option>
                                    <option value="2">SMS Pack</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <div class="title">Plan</div>
                                <input type="text" autocomplete="off" class="form-control plan_entry_control" id="plan_name_master" name="plan_name_master" value="<?php echo e(old('plan_name_master')); ?>"/>
                            </div>



                            <div class="form-group">
                                <div class="title">Amount</div>
                                <input type="text" autocomplete="off" class="form-control plan_entry_control" id="plan_entry_amount" name="plan_entry_amount" value="<?php echo e(old('plan_entry_amount')); ?>"/>
                            </div>

                            <div class="form-group">
                                <div class="title">SMS Count</div>
                                <input type="text" autocomplete="off" class="form-control plan_entry_control" id="sms_count" name="sms_count" value="<?php echo e(old('sms_count')); ?>"/>
                            </div>


                            
                        </div>
                        <div class="col-md-6">

                            <div class="form-group tennure-group">

                                <div class="title">Tennure</div>

                                <input placeholder="In Months" name="tennure" type="text" value="<?php echo e(old('tennure')); ?>" class="form-control  plan_entry_control " id="tennure" autocomplete="off">

                                <input placeholder="In Days" name="tennure_in_days" type="text" value="<?php echo e(old('tennure_in_days')); ?>" class="form-control  plan_entry_control" id="tennure_in_days" autocomplete="off">

                            </div>

                            

                            <div class="pub_prv">
                                <div class="title ">Display Type</div>
                                <select name="pub_prv_access" id="pub_prv_access" required="required" >
                                    <option value="0">public</option>
                                    <option value="1">private</option>
                                </select>
                            </div>




                            <div class="submit_wrapper form-group">
                                <button id="plan_entry_submit" type="submit" class="btn btn-primary plan_submit">Save</button>
                            </div>

                        </div>

                    </div>

                </div>
            </form>

            <div class="plan_list">


                <table id="grid" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Sno</th>
                            <th>Plan Name</th>
                            <th>Plan Type</th>
                            <th>SMS Count</th>
                            <th>Tennure</th>
                            <th>Amount</th>
                            <th>Display Type </th>
                            <th>Edit Existing Plan</th>
                            <th>Status</th>
                        </tr>
                        </tr>
                    </thead>
                    <tbody> 
                        <?php $i = 1; ?>
                        <?php $__currentLoopData = $plan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i); ?></td>
                            <td><?php echo e($p->CPE_PLAN_NAME); ?></td>
                            <td><?php echo e($p->CPE_PLAN_TYPE); ?></td>
                            <td><?php echo e($p->CPE_SMS_ALLOTED); ?></td> 
                            <td><?php echo e($p->CPE_TENURE_MONTHS); ?></td>
                            <td><?php echo e($p->CPE_AMOUNT); ?></td>
                            <td><?php echo e($p->CPE_DISPLAY_TYPE); ?></td> 
                            <td><input type="button" value="Edit"/></td>
                            <td><?php echo e($p->CPE_ACTIVE_STATUS); ?></td>
                        </tr>
                        <?php $i = $i + 1; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>

        </section>
    </div>

<script src="<?php echo url('bower_components/jquery/dist/jquery.min.js'); ?>"></script>


<script type="text/javascript">

var APP_URL = <?php echo json_encode(url('/')); ?>;
$.ajaxSetup({

headers: {

'X-CSRF-TOKEN': $('#plan_token').val()

        }

});
$("#plan_entry_form").submit(function(e){
e.preventDefault();
$.ajax({

type:'GET',
        url:APP_URL + "/create/plan",
        data:$('#plan_entry_form').serialize(),
        success:function(data){
        //$('#myModal').modal('show');
        }
});
});


</script>