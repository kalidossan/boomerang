
<h2>My Customers </h2>

                   <table id="grid" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Sno</th>
                            <th>Name</th>
                            <th>Mobile No</th>
                            <th>E-mail</th>
                            <th>Date Of Birth</th>
                            <th>Anniverasry Date</th>
                            <th>Gender</th>
                            <th>Categories</th>
                        </tr>
                        </tr>
                    </thead>
                    <tbody> 
                        <?php $i = 1; ?>
                        <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i); ?></td>
                            <td><?php echo e($p->CCM_FIRST_NAME); ?></td>
                            <td><?php echo e($p->CCM_MOBILE_NO); ?></td>                        
                            <td><?php echo e($p->CCM_EMAIL_ID); ?></td>
                            <td>
                            <?php
                            $date = new DateTime($p->CCM_DOB);
                            echo $date->format('m-d-Y');
                            ?>
                            </td> 
                            <td>
                                <?php
                            $date = new DateTime($p->CCM_DOA);
                            echo $date->format('m-d-Y');
                            ?>
                            </td>
                            <td>
                                <?php if($p->CCM_GENDER=='0'): ?>
                                <?php echo e("Male"); ?>

                                <?php else: ?>
                                <?php echo e("Female"); ?>

                                <?php endif; ?>
                            </td>
                            <th>Categories</th>
                        </tr>
                        <?php $i = $i + 1; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

