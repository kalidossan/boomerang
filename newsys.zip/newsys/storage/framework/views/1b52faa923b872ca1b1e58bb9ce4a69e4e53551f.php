<a href="#" id="message_center">Message Center</a>

<div class="content-wrapper">

    <h2>Message History</h2>
    
                <table id="grid" class="table table-bordered table-striped">
                    <tbody> 
                        <?php $__currentLoopData = $message_history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                                                   
                                <textarea rows="4" cols="50">
                                    <?php echo e($message->CMH_TITLE); ?> 
                                    <?php echo e($message->CMH_CONTENT); ?>

                                 </textarea> 

                            </td>
                            <td></td>
                            <td>
                              <input type="submit" class="send-again btn btn-primary" value="Send Again" name="message_history_submit" /> 
                            </td>
                    
                       
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

</div>

