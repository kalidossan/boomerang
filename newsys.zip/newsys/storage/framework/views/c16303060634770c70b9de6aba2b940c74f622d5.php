<div id="config_settings" class="config_settings"> 
                    <ul  class="nav nav-pills tab" id="settingsMenu">
                    
                        <li class="active"><a href="#my-profile" data-toggle="tab" aria-expanded="true" >Profile</a>
                        </li>
                        <li><a href="#reset-password" data-toggle="tab">Reset Password</a>
                        </li>
                        <li><a href="#sender-id" data-toggle="tab">Sender ID</a>
                        </li>
                        <li><a href="#category" data-toggle="tab">Categories</a>
                        </li>                      
                        
                        <li>
                            <a href="#bulk-upload" data-toggle="tab">Customer Upload</a>
                        </li>

                    </ul>

                    <div class="tab-content clearfix">

                         <div class="tab-pane fade in active"  id="my-profile">

                            <?php echo $__env->make('retailer.profile', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
         
                        </div>

                        <div class="tab-pane" id="reset-password">

                            <?php echo $__env->make('retailer.retailer_reset', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
         
                        </div>

                           <div class="tab-pane" id="sender-id">

                            <?php echo $__env->make('retailer.bulk_upload', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
         
                        </div>
                        
                       
                         <div class="tab-pane" id="category">

                            <?php echo $__env->make('retailer.retailer_category', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 
                        </div>

                      
                        

                        <div class="tab-pane" id="bulk-upload">

                            <?php echo $__env->make('retailer.bulk_upload', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
         
                        </div>

                    </div>
                </div>