<div id="retailer_registration"> 
   
        <form method="GET" id="profile_update" ">

            <div class="col-sm-6 panel">


                <div class="box-body">
                    <div class="row">
                        <div class="col-md-12">
                            <input type="hidden" value="<?php echo e(csrf_token()); ?>" id="profile_token" name="profile_token" />

                              <div class="form-group">
                                <div class="title">Mobile No</div>
                                <input type="text" autocomplete="off" class="form-control retailer_registration" id="reg_mobile" name="reg_mobile" value="<?php echo e(old('mobile')); ?>" maxlength="10" required="required"/>
                            </div>

                            <div class="form-group">
                                <div class="title">Business Category</div>

                           
                            </div>



                            <div class="form-group">
                                <div class="title">Business Name</div>
                                <input type="text" autocomplete="off" class="form-control retailer_registration" id="reg_biz_name" name="reg_biz_name" value="<?php echo e(old('biz_name')); ?>"/>
                            </div>

                            <div class="form-group">
                                <div class="title">First Name</div>
                                <input type="text" autocomplete="off" class="form-control retailer_registration" id="first_name" name="first_name" value="<?php echo e(old('first_name')); ?>"/>
                            </div>
                            <div class="form-group">
                                <div class="title">Last Name</div>
                                <input type="text" autocomplete="off" class="form-control retailer_registration" id= "last_name" name="last_name" value="<?php echo e(old('last_name')); ?>"/>
                            </div>
                            <div class="form-group">
                                <div class="title">E-Mail</div>
                                <input type="email" autocomplete="off" class="form-control retailer_registration" id="mail" name="mail" value="<?php echo e(old('mail')); ?>"/>
                            </div>
                          


                            <div class="form-group">
                                <div class="title">Business Starting Date</div>

                                <div class="input-group date">
                                    <div class="input-group-addon">
                                        <i class="fa fa-calendar"></i>
                                    </div>
                                    <input autocomplete="off" name="dos" type="text" value="<?php echo e(old('dos')); ?>" class="form-control pull-right " id="dos" autocomplete="off">
                                </div>

                            </div>

                            <div class="form-group">
                                <div class="title">GST No</div>
                                <input type="mobile" autocomplete="off" class="form-control retailer_registration" id="gst_no" name="gst_no" value="<?php echo e(old('gst_no')); ?>"/>
                            </div>

                              <div class="form-group">
                    <div class="title">Fb Address</div>
                    <input type="text" autocomplete="off" class="form-control retailer_registration" id="fb_id" name="fb_id" value="<?php echo e(old('fb_id')); ?>"/>
                </div>
                <div class="form-group">
                    <div class="title">Instagram ID</div>
                    <input type="text" autocomplete="off" class="form-control retailer_registration" id="instagram_id" name="instagram_id" value="<?php echo e(old('instagram_id')); ?>"/>
                </div>

                        </div>

                    </div>

                </div>
            </div>

            <div class="col-sm-6 panel">
              
                <div class="form-group">
                    <div class="title">Pin Code</div>
                    <input type="text" autocomplete="off" class="form-control retailer_registration" id="pincode" name="pincode" value="<?php echo e(old('pincode')); ?>"/>
                </div>
                <div class="form-group">
                    <div class="title">State</div>
                    <input type="text" autocomplete="off" class="form-control retailer_registration" id="state" name="state" value="<?php echo e(old('state')); ?>"/>
                </div>
                <div class="form-group">
                    <div class="title">City </div>
                    <input type="text" autocomplete="off" class="form-control retailer_registration" id="city" name="city" value="<?php echo e(old('city')); ?>"/>
                </div>
                <div class="form-group">
                    <div class="title">Area </div>
                    <input type="text" autocomplete="off" class="form-control retailer_registration" id="area" name="area" value="<?php echo e(old('area')); ?>"/>
                </div>
                <div class="form-group">
                    <div class="title">Street </div>
                    <input type="text" autocomplete="off" class="form-control retailer_registration" id="street" name="street" value="<?php echo e(old('street')); ?>"/>
                </div>
                <div class="form-group">
                    <div class="title">Plot/Flat No </div>
                    <input type="text" autocomplete="off" class="form-control retailer_registration" id="flat_no" name="flat_no" value="<?php echo e(old('flat_no')); ?>"/>
                </div>
                <div class="form-group">
                    <button id="retailer_registration_submit" type="submit" class="btn btn-primary">Create</button>

            </div>
          
            </div>
        </form>

</div>

<div id="regModal" class="modal fade" role="dialog">
    <div class="modal-dialog modal-sm">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <div class="success"></div>
                <button type="button" class="close" data-dismiss="modal">×</button>
            </div>
            <div class="modal-body">
               
               <div class="customer"></div> Retailers Updated Successfully <div class="first_name"></div>
               
            </div>
           
        </div>

    </div>
</div>

<script src="<?php echo url('bower_components/jquery/dist/jquery.min.js'); ?>"></script>

<script type="text/javascript">

var APP_URL = <?php echo json_encode(url('/')); ?>;
$.ajaxSetup({
headers: {'X-CSRF-TOKEN': $('#token').val()}
});
$("#profile_update").submit(function(e){
var token = $('#profile_token').val();
e.preventDefault();
$.ajax({
type:'GET',
        url:APP_URL + "/retailer/registration",
        data:$('#form_registration').serialize() + "&token=" + token,
        success:function(data){

            $('.success').text(data.success)

            
        }
});
});

</script>












