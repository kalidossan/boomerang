<header class="main-header">
    <!-- Logo -->
    <a href="#" class="logo">
        <!-- mini logo for sidebar mini 50x50 pixels -->
        <span class="logo-mini"><b>S</b>C</span>
        <!-- logo for regular state and mobile devices -->
        <span class="logo-lg"> Boomerang</span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
        <!-- Sidebar toggle button-->

        <div class="navbar-custom-menu">


<?php if(auth()->guard()->guest()): ?>
            <ul class="nav navbar-nav">
                  <li>
                     <a href="<?php echo e(url('home')); ?>"class="text-center">Home</a>

                </li>

                  <li>
                     <a href="<?php echo e(url('about')); ?>" class="text-center">About Us</a>

                </li>

                <li>
                     <a href="<?php echo e(url('products')); ?>" class="text-center">Products </a>

                </li>
                <li>
                     <a href="<?php echo e(url('contact')); ?>" class="text-center">Contact Us </a>
         </li>
     </ul>
<?php endif; ?>
            <ul class="nav navbar-nav pull-right">
                <!-- Messages: style can be found in dropdown.less-->

                </li>

                <!-- Tasks: style can be found in dropdown.less -->
                <li class="dropdown tasks-menu">
                    <?php if(!(Auth::check())): ?> 
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        LOGIN
                    </a>
                    <?php endif; ?>
                    <ul class="dropdown-menu">

                        <!-- /.login-logo -->
                        <div class="login-box-body">
                            <p class="login-box-msg">Sign in to start your session</p>

                            <form  method="POST" action="<?php echo e(route('login')); ?>">
                                <?php echo e(csrf_field()); ?>

                                <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?> has-feedback">
                                    <input id="email" type="text" placeholder="Email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required autofocus>

                                    <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                    <span class="glyphicon glyphicon-phone form-control-feedback"></span>
                                </div>
                                <div class="form-group has-feedback">
                                    <input id="password" placeholder="Password" type="password" class="form-control" name="password" required>

                                    <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                    <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                                </div>
                                <div class="form-group">
                                    <div class="col-md-8 col-md-offset-4">
                                        <button type="submit" class="btn btn-primary">
                                            Login
                                        </button>


                                    </div>
                                </div>
                            </form>



                            <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                Forgot Your Password?
                            </a><br>
                            <a href="register.html" class="text-center">Register a new membership</a>

                        </div>
                        <!-- /.login-box-body -->

                    </ul>
                </li>

                <!-- User Account: style can be found in dropdown.less -->

                <?php if(auth()->guard()->guest()): ?>
                <li><a href="<?php echo e(url('registration-sign-up')); ?>">REGISTER</a></li>

                <?php else: ?>
                

                  <ul class="nav navbar-nav retailer-menu">
                   
                 <?php if(Auth::user()->biz_id !== 0): ?>
                  <li>
                     <div class="messge-center-panel text-center"><a href="<?php echo e(url('retailer')); ?>">Message Center</a></div>

                </li>

                  <li>
                    <div class="configuration-panel text-center">Configuration</div>
                </li>

                <li>
                    <div class="customer-request-panel text-center">Customer's Request</div>
                </li>
                <li class="yellow">
                    SMS Balance : <span><?php echo e(Auth::user()->sms_balance); ?></span>
                </li>
                <?php endif; ?>

                <?php if(Auth::user()->role_id == 1): ?>
                <li>

                    <?php $retailers_list = retailerList(); ?>
             
                        <select class="form-control select2 retailers_list" name="retailers_list" id="retailers_list">
                                <option value="0">Admin Panel</option>
                                <?php $__currentLoopData = $retailers_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $retailer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($retailer->RET_BIZ_ID); ?>" 

                            <?php echo (Auth::user()->biz_id == $retailer->RET_BIZ_ID)?  "selected" : "" ?>
                                    
                                    ><?php echo e($retailer->RET_MOBILE_NO); ?></option>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>


                 </li>
                 <?php endif; ?>
     </ul>
                
                <li class="dropdown user user-menu">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <span class="hidden-xs"><?php echo e(Auth::user()->name); ?></span>
                    </a>
                    <ul class="dropdown-menu">
                        <!-- User image -->
                        <li class="user-header">

                            <p>
                                <?php echo e(Auth::user()->name); ?>

                                <small>Member since Nov. 2017</small>
                            </p>
                        </li>
                        <!-- Menu Body -->
                        <li class="user-body">
                            <div class="row">
                                <div class="col-xs-4 text-center">
                                    <a href="#">Followers</a>
                                </div>
                                <div class="col-xs-4 text-center">
                                    <a href="#">Sales</a>
                                </div>
                                <div class="col-xs-4 text-center">
                                    <a href="#">Friends</a>
                                </div>
                            </div>
                            <!-- /.row -->
                        </li>
                        <!-- Menu Footer-->
                        <li class="user-footer">
                            <div class="pull-left">
                                <a href="#" class="btn btn-default btn-flat">Profile</a>
                            </div>
                            <div class="pull-right">
                                <a href="<?php echo e(route('logout')); ?>" class="btn btn-default btn-flat"
                                   onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();">Sign out</a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo e(csrf_field()); ?>

                                </form>
                            </div>
                        </li>
                    </ul>
                </li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>
</header>
