<div class="container">
        <?php if( Session::has('success') ): ?>
        <div class="alert alert-success alert-dismissible" role="alert">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
            <span class="sr-only">Close</span>
        </button>
        <strong><?php echo e(Session::get('success')); ?></strong>
    </div>
    <?php endif; ?>
 
    <?php if( Session::has('error') ): ?>
    <div class="alert alert-danger alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
            <span class="sr-only">Close</span>
        </button>
        <strong><?php echo e(Session::get('error')); ?></strong>
    </div>
    <?php endif; ?>
 
    <?php if(count($errors) > 0): ?>
    <div class="alert alert-danger">
      <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
      <div>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p><?php echo e($error); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php endif; ?>

<div class="row">
    <div><a class="btn btn-primary btn-sm" href="<?php echo e(url('/download-tpl')); ?>">Download  Template</a></div>

</div>
 
<form class="import-customers" action="<?php echo e(route('import')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>


     <div class="xls-title" >Choose your xls/csv File : </div>

     <input type="file" name="file" class="form-control bulk-upload">
 
    <input type="submit" class="btn btn-primary btn-sm" style="margin-left: 3%">
</form>


 
</div>