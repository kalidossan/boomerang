Hi <?php echo e(@$user); ?>,
Your password reset OTP is <?php echo e(@$token); ?>.

https://bit.ly/2IxXJbp

Regards,
XYZ