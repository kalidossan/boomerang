<?php echo e(@$title); ?>,

<?php echo e(@$msg); ?>.

https://bit.ly/2IxXJbp
