<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <section class="content">
        <div class="box box-default center">   
            <div class="col-sm-3 panel">
                <?php echo $__env->make('retailer.customer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <div id="main-panel" class="col-sm-6 panel"  >


                <div id="scheduler_message_reports" class="scheduler">	
                    <ul  class="nav nav-pills tab" id="tabMenu">
                        <li class="active">
                            <a  href="#scheduler" data-toggle="tab">Scheduler</a>
                        </li>
                        <li><a href="#message" data-toggle="tab">Message Center</a>
                        </li>
                        <li><a href="#reports" data-toggle="tab">Reports</a>
                        </li>         

                    </ul>

                    <div class="tab-content clearfix">
                        <div class="tab-pane active" id="scheduler">
                            <div class="row">
                                <div class="col-md-12 ">
                                    <div class="panel panel-default">
                                        <div class="panel-heading">Scheduler</div>
                                        <div class="panel-body">
                                            <?php echo $calendar->calendar(); ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane" id="message">
                            <?php echo $__env->make('retailer.message_center', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </div>
                        <div class="tab-pane" id="reports">
                            
                            <?php echo $__env->make('retailer.retailer_report', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </div>
                        

                    </div>
                </div>
            </div>
            <div class="col-sm-3 panel">
                <?php echo $__env->make('retailer.recent_update', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
        <!-- /.box -->
    </section>




</div>
<?php echo $__env->make('retailer.retailer_modals', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('retailer.retailer_js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>








<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>