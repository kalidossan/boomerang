<a href="#" id="message_center">Message Center</a>

<div class="content-wrapper">

    <h2>Message History</h2>
    
                <table id="grid" class="table table-bordered table-striped">
                    <tbody> 
                        @foreach($message_history as $message)
                        <tr>
                            <td>
                                                                   
                                <textarea rows="4" cols="50">
                                    {{$message->CMH_TITLE}} 
                                    {{$message->CMH_CONTENT}}
                                 </textarea> 

                            </td>
                            <td></td>
                            <td>
                              <input type="submit" class="send-again btn btn-primary" value="Send Again" name="message_history_submit" /> 
                            </td>
                    
                       
                        </tr>
                        @endforeach
                    </tbody>
                </table>

</div>

