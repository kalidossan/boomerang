 <div id="alerts">
                    <div class="box-header">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="top-bar-title padding-bottom"><i class="fa fa-pencil-square-o"></i>New Customer Registration</div>
                            </div> 
                        </div>            
                    </div>

                    
                    <div class="recent_updates">
                        <div class="row">
                            <div class="col-md-10 title">
                                Title
                            </div> 
                            <div class="col-md-10 Desciption">
                                Today we are share with you one common but verry important tutorial ho.....
                            </div> 
                        </div>            
                    </div>

                    <div class="recent_updates">
                        <div class="row">
                            <div class="col-md-10 title">
                                Title
                            </div> 
                            <div class="col-md-10 Desciption">
                                Today we are share with you one common but verry important tutorial ho.....
                            </div> 
                        </div>            
                    </div>
                    <div class="recent_updates">
                        <div class="row">
                            <div class="col-md-10 title">
                                Title
                            </div> 
                            <div class="col-md-10 Desciption">
                                Today we are share with you one common but verry important tutorial ho.....
                            </div> 
                        </div>            
                    </div>
                    <div class="recent_updates">
                        <div class="row">
                            <div class="col-md-10 title">
                                Title
                            </div> 
                            <div class="col-md-10 Desciption">
                                Today we are share with you one common but verry important tutorial ho.....
                            </div> 
                        </div>            
                    </div>
                    <div class="recent_updates">
                        <div class="row">
                            <div class="col-md-10 title">
                                Title
                            </div> 
                            <div class="col-md-10 Desciption">
                                Today we are share with you one common but verry important tutorial ho.....
                            </div> 
                        </div>            
                    </div>
                    <div class="recent_updates">
                        <div class="row">
                            <div class="col-md-10 title">
                                Title
                            </div> 
                            <div class="col-md-10 Desciption">
                                Today we are share with you one common but verry important tutorial ho.....
                            </div> 
                        </div>            
                    </div>
                    


                </div>