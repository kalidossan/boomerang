<div id="config_settings" class="config_settings"> 
                    <ul  class="nav nav-pills tab" id="settingsMenu">
                    
                        <li class="active"><a href="#my-profile" data-toggle="tab" aria-expanded="true" >Profile</a>
                        </li>
                        <li><a href="#reset-password" data-toggle="tab">Reset Password</a>
                        </li>
                        <li><a href="#sender-id" data-toggle="tab">Sender ID</a>
                        </li>
                        <li><a href="#category" data-toggle="tab">Categories</a>
                        </li>                      
                        
                        <li>
                            <a href="#bulk-upload" data-toggle="tab">Customer Upload</a>
                        </li>

                    </ul>

                    <div class="tab-content clearfix">

                         <div class="tab-pane fade in active"  id="my-profile">

                            @include('retailer.profile')
         
                        </div>

                        <div class="tab-pane" id="reset-password">

                            @include('retailer.retailer_reset')
         
                        </div>

                           <div class="tab-pane" id="sender-id">

                            @include('retailer.bulk_upload')
         
                        </div>
                        
                       
                         <div class="tab-pane" id="category">

                            @include('retailer.retailer_category')
 
                        </div>

                      
                        

                        <div class="tab-pane" id="bulk-upload">

                            @include('retailer.bulk_upload')
         
                        </div>

                    </div>
                </div>