
                            <a href="#" id="message_history">Message History</a>    

                            <select name="language_type" id="language_type" required="required" >
                                <option value="0">English</option>
                                <option value="1">Tamil</option>
                            </select>
                            <form  id="mc_form">

                                <div class="box-body">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <input type="hidden" value="{{csrf_token()}}" id="token2" name="_token2" />
                                            <div class="events_festival">
                                                <select name="message_type" id="message_type" required="required" >
                                                    <option value="0">Events And Festival</option>
                                                    <option value="1">Birthday Wishes</option>
                                                    <option value="2">Marriage Anniversary Wishes</option>
                                                </select>
                                            </div>

                                            <div class="form-group">
                                                <div class="title">Message Title</div>
                                                <input type="text" autocomplete="off" class="form-control customer_registration" id="message_title" name="message_title" value="{{ old('message_title') }}" required="required" />
                                            </div>

                                            <div class="form-group">
                                                <div class="title">Message Text</div>
                                                <textarea cols="5" rows="5" onkeyup="countChar(this)" id="msg_txt" class="form-control" name="msg_txt"> <?php if (old('arequest')) { ?>{{ old('arequest') }}<?php } ?></textarea> <span id="charNum"></span>
                                            </div>
                                           
                                        </div>
                                        <div class="col-md-12 events_festival_only">


                                            <div class="form-group">
                                                <div class="title">Valid Till</div>

                                                <div class="input-group date">
                                                    <div class="input-group-addon">
                                                        <i class="fa fa-calendar"></i>
                                                    </div>
                                                    <input autocomplete="off" name="valid_till" type="text" value="{{ old('valid_till') }}" class="form-control pull-right " id="valid_till" autocomplete="off">
                                                </div>

                                                <div class="title">Time</div>

                                                <div class="input-group date">
                                                    <div class="input-group-addon">
                                                        <i class="fa fa-calendar"></i>
                                                    </div>
                                                    <input autocomplete="off" name="valid_till_time" type="text" value="{{ old('valid_till_time') }}" class="form-control pull-right " id="valid_till_time" autocomplete="off">
                                                </div>

                                            </div>

                                            <div class="pull-left">Target Audience</div>
                                            <div class="form-group">
                                                <div class="radio">
                                                    <div class="title">
                                                        <input type="radio" name="gender_group" id="tar_male" value="0" checked="">
                                                        Male                                            </div>
                                                </div>
                                                <div class="radio">
                                                    <div class="title">
                                                        <input type="radio" name="gender_group" id="tar_female" value="1">
                                                        Female                                            </div>
                                                </div>
                                                <div class="radio">
                                                    <div class="title">
                                                        <input type="radio" name="gender_group" id="both" value="2">
                                                        Both                                            </div>
                                                </div>

                                            </div>

                                            <div class="form-group">
                                                <div class="radio">
                                                    <div class="title">
                                                        <input type="radio" name="cust_pros_target" id="customer" value="0" checked="">
                                                        Customer                                            </div>
                                                </div>
                                                <div class="radio">
                                                    <div class="title">
                                                        <input type="radio" name="cust_pros_target" id="prospect" value="1">
                                                        Prospect                                            </div>
                                                </div>
                                                <div class="radio">
                                                    <div class="title">
                                                        <input type="radio" name="cust_pros_target" id="cust_pros_target" value="2">
                                                        Both                                            </div>
                                                </div>

                                            </div>

                                            <div id="message_center_categories" class="category_wrapper pull-left">
                                                     @foreach($categories_label as $category_label)
                                                    <div  class="wrapper_category">
                                                    <div class="title" name="{{$category_label->CCM_ID}}">{{$category_label->CCM_LABEL_NAME}}</div>

                                                    <select class="form-control select2 select2-hidden-accessible mc_category_values" multiple="multiple"  name="mc_category_{{$category_label->CCM_ID}}" id="mc_category_{{$category_label->CCM_ID}}"  >
                                                        @foreach($categories as $category)
                                                        @if($category->CCVM_CCM_ID == $category_label->CCM_ID)
                                                        <option value="{{$category->CCVM_ID}}">{{$category->CCVM_VALUE}}</option>
                                                        @endif
                                                        @endforeach
                                                    </select>
                                                     </div>
                                                    @endforeach

                                               
                                            </div>


                                           
                                        </div>
                                         <div class="submit_wrapper form-group">
                                                <button id="mc_submit" type="submit" class="btn btn-primary mc_submit">Preview & Save</button>
                                            </div>

                                    </div>

                                </div>
                            </form>
                   
        