                <div id="config_settings" class="config_settings">	
                    <ul  class="nav nav-pills tab" id="settingsMenu">
                    
                        <li><a href="#category" data-toggle="tab">Category Settings</a>
                        </li>
                        <li><a href="#profile" data-toggle="tab">Profile Settings</a>
                        </li>

                    </ul>

                    <div class="tab-content clearfix">
                        
                       
                         <div class="tab-pane" id="category">

                            @include('retailer.retailer_category')
 
                        </div>
                         <div class="tab-pane" id="profile">
         
                        </div>

                    </div>
                </div>