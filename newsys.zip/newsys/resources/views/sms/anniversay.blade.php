Hi {{ @$user }},
Your password reset OTP is {{ @$token }}.

https://bit.ly/2IxXJbp

Regards,
XYZ