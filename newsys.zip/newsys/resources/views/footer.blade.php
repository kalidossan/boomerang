<div class="pull-right hidden-xs">
</div>
<strong>Copyright &copy; 2018 <a href="#">Boomerang</a>.</strong> All rights
reserved.
